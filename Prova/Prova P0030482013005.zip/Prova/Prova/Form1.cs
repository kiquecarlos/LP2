﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Globalization;

namespace Prova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Run_Click(object sender, EventArgs e)
        {
            string input;
            double[,] vendas = new double[5,4];
            double venda;
            double totalMês;
            double totalFinal;


            for (int i = 0; i < 5; i++)
            {

                for (int j = 0; j < 4; j++)
                {

                    while (true)
                    {
                        input = Interaction.InputBox($"Digite o  Total de Venda da Semana {j + 1} do Mês {i + 1}");
                        if (double.TryParse(input, out vendas[i, j]))
                        {
                            break;
                        }
                        MessageBox.Show("Valor Digitado Inválido Digite Novamente");
                        

                    }

                }


            }
            totalFinal = 0;

            for (int i = 0; i < 5; i++)
            {

                totalMês = 0;
                for (int j = 0; j < 4; j++) {

                    venda = vendas[i, j];

                    totalMês = totalMês + venda;

                    lb_result.Items.Add($"Total do mês: {i+1} Semana: {j+1} {venda.ToString("C", CultureInfo.CurrentCulture)}");
                }

                totalFinal = totalFinal + totalMês;

                lb_result.Items.Add($">> Total Mês:  {totalMês.ToString("C", CultureInfo.CurrentCulture)}");

                lb_result.Items.Add("-------------------------");

            }
            lb_result.Items.Add($">> Total Geral:  {totalFinal.ToString("C", CultureInfo.CurrentCulture)}");
        }
    }
}
