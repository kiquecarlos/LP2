﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btSomar_Click(object sender, EventArgs e)
        {
            double number1, number2, resultado;

            if (Double.TryParse(tbNumero1.Text, out number1) && Double.TryParse(tbNumero2.Text, out number2))
            {

                resultado = number1 + number2;

                tbResultado.Text = resultado.ToString();
            }
            else
                tbResultado.Text = "Digite Valores Válidos";
        }

        private void btSubtrair_Click(object sender, EventArgs e)
        {
            double number1, number2, resultado;

            if (Double.TryParse(tbNumero1.Text, out number1) && Double.TryParse(tbNumero2.Text, out number2))
            {

                resultado = number1 - number2;

                tbResultado.Text = resultado.ToString();
            }
            else
                tbResultado.Text = "Digite Valores Válidos";
        }

        private void btMultiplicar_Click(object sender, EventArgs e)
        {
            double number1, number2, resultado;

            if (Double.TryParse(tbNumero1.Text, out number1) && Double.TryParse(tbNumero2.Text, out number2))
            {

                resultado = number1 * number2;

                tbResultado.Text = resultado.ToString();
            }
            else
                tbResultado.Text = "Digite Valores Válidos";
        }

        private void btDividir_Click(object sender, EventArgs e)
        {
            double number1, number2, resultado;

            if (Double.TryParse(tbNumero1.Text, out number1) && Double.TryParse(tbNumero2.Text, out number2))
            {

                resultado = number1 / number2;

                tbResultado.Text = resultado.ToString();
            }
            else
                tbResultado.Text = "Digite Valores Válidos";
        }

        private void btLimpar_Click(object sender, EventArgs e)
        {
            tbResultado.Text = "";
            tbNumero2.Text = "";
            tbNumero1.Text = "";
        }
    }
}
