﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace matrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_Run_Click(object sender, EventArgs e)
        {
            string input;
            string[] nomes = new string[5];
            string NomeLimpo;
            int qtdChars;


            for (int i = 0; i < 5; i++)
            {
                input = Interaction.InputBox($"Digite um nome {i+1}/5 ");

                NomeLimpo = input.Replace(" ","");


                qtdChars = NomeLimpo.Length;

                nomes[i] = $"o nome:{input} tem {qtdChars} caracteres";

            }

            foreach(string nome in nomes)
            {
                lb_result.Items.Add(nome);
            }

        }
    }
}
