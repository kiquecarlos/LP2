﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace matrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_ex1_Click(object sender, EventArgs e)
        {
            int[] numeros = new int[20];
            string input;
            string resultado = "";
            for (int i = 0; i < 20; i++)
            {

                while (true)
                {
                    input = Interaction.InputBox($"Digite um valor {i+1}/20 ");
                    if(int.TryParse(input, out numeros[i]))
                    {
                        break;
                    }
                    MessageBox.Show("Valor Digitado Inválido Digite Novamente");
                }          
            }
            for (int i = (numeros.Length-1); i >= 0; i--)
            {
                resultado = $"{resultado} {numeros[i]}";
            }


            MessageBox.Show(resultado);

        }

        private void btn_ex2_Click(object sender, EventArgs e)
        {
            int[] numeros = new int[20];
            string input;
            string resultado = "";
            for (int i = 0; i < 20; i++)
            {

                while (true)
                {
                    input = Interaction.InputBox($"Digite um valor {i + 1}/20 ");
                    if (int.TryParse(input, out numeros[i]))
                    {
                        break;
                    }
                    MessageBox.Show("Valor Digitado Inválido Digite Novamente");
                }
             
            }
            Array.Reverse(numeros);
            resultado = String.Join(" ", numeros);


            MessageBox.Show(resultado);
        }

        private void btn_ex3_Click(object sender, EventArgs e)
        {
            int[] quantidade = new int[10];
            float[] preco = new float[10];
            string input;
            float resultado = 0;
            for (int i = 0; i < 10; i++)
            {

                while (true)
                {
                    input = Interaction.InputBox($"Digite a quantidade da mercadoria {i + 1}/10 ");
                    if (int.TryParse(input, out quantidade[i]))
                    {
                        break;
                    }
                    MessageBox.Show("Valor Digitado Inválido Digite Novamente");
                }


                while (true)
                {
                    input = Interaction.InputBox($"Digite o preço da mercadoria {i + 1}/10 ");
                    if (float.TryParse(input, out preco[i]))
                    {
                        break;
                    }
                    MessageBox.Show("Valor Digitado Inválido Digite Novamente");
                }

            }

            for (int i = 0; i < 10; i++)
            {
                resultado =resultado + quantidade[i] * preco[i];
            }


            MessageBox.Show("O total de faturamento do mês foi " + resultado.ToString("C"));
        }

        private void btn_ex4_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
"Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }

            MessageBox.Show("O Total é "+Total.ToString());
        }

        private void btn_ex5_Click(object sender, EventArgs e)
        {
            string[] nomes = { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            var listaNomes = nomes.ToList();
            string result = "";

            listaNomes.Remove("Otávio");

            nomes = listaNomes.ToArray();

            result = String.Join(" ", nomes);


            MessageBox.Show(result);

        }

        private void btn_ex6_Click(object sender, EventArgs e)
        {
            float[,] alunos = new float[20, 3];
            string input;
            string result = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    while (true)
                    {
                        input = Interaction.InputBox($"Digite a nota {j+1} do aluno {i + 1}");
                        if (float.TryParse(input, out alunos[i,j]))
                        {
                            break;
                        }
                        MessageBox.Show("Valor Digitado Inválido Digite Novamente");
                    }
                }
            }

            for (int i = 0; i < 20; i++)
            {
                result = $"{result}Aluno {i+1}: média:{(alunos[i, 0]+ alunos[i, 1]+ alunos[i, 2])/3}\n";
            }

                MessageBox.Show(result);
        }

        private void btn_ex7_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
        }
    }
    
}
