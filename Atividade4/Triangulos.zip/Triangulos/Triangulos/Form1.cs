﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btCalcular_Click(object sender, EventArgs e)
        {
            Double LadoA, LadoB, LadoC;
            String resultado;

            if (Double.TryParse(tbLadoA.Text, out LadoA)&& Double.TryParse(tbLadoB.Text, out LadoB)&& Double.TryParse(tbLadoC.Text, out LadoC))
            {
                if ((Math.Abs(LadoB - LadoC) < LadoA  && LadoA < (LadoB + LadoC)) || (Math.Abs(LadoA - LadoC) < LadoB && LadoB < (LadoA + LadoC)) || (Math.Abs(LadoA - LadoB) < LadoC && LadoC < (LadoA + LadoB)))
                {
                    if (LadoA != LadoB && LadoA != LadoC && LadoB != LadoC)
                        resultado = "Triângulo Escaleno";
                    else if (LadoA == LadoB && LadoA == LadoC)
                        resultado = "Triângulo Equilatero";
                    else
                        resultado = "Triângulo Isósceles";
                }
                else
                {
                    resultado = "Triângulo não Existe";
                }

                lbResultado.Text = resultado;
            }                
            else
                MessageBox.Show("Digite Valores Válidos");
        }
    }
}
