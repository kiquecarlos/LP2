﻿namespace Triangulos
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbLadoA = new System.Windows.Forms.Label();
            this.lbLadoB = new System.Windows.Forms.Label();
            this.lbLadoC = new System.Windows.Forms.Label();
            this.tbLadoA = new System.Windows.Forms.TextBox();
            this.tbLadoB = new System.Windows.Forms.TextBox();
            this.tbLadoC = new System.Windows.Forms.TextBox();
            this.btCalcular = new System.Windows.Forms.Button();
            this.lbResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbLadoA
            // 
            this.lbLadoA.AutoSize = true;
            this.lbLadoA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLadoA.Location = new System.Drawing.Point(12, 34);
            this.lbLadoA.Name = "lbLadoA";
            this.lbLadoA.Size = new System.Drawing.Size(76, 24);
            this.lbLadoA.TabIndex = 0;
            this.lbLadoA.Text = "Lado A";
            // 
            // lbLadoB
            // 
            this.lbLadoB.AutoSize = true;
            this.lbLadoB.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLadoB.Location = new System.Drawing.Point(187, 34);
            this.lbLadoB.Name = "lbLadoB";
            this.lbLadoB.Size = new System.Drawing.Size(75, 24);
            this.lbLadoB.TabIndex = 1;
            this.lbLadoB.Text = "Lado B";
            // 
            // lbLadoC
            // 
            this.lbLadoC.AutoSize = true;
            this.lbLadoC.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLadoC.Location = new System.Drawing.Point(348, 34);
            this.lbLadoC.Name = "lbLadoC";
            this.lbLadoC.Size = new System.Drawing.Size(76, 24);
            this.lbLadoC.TabIndex = 2;
            this.lbLadoC.Text = "Lado C";
            // 
            // tbLadoA
            // 
            this.tbLadoA.Location = new System.Drawing.Point(16, 73);
            this.tbLadoA.Name = "tbLadoA";
            this.tbLadoA.Size = new System.Drawing.Size(100, 20);
            this.tbLadoA.TabIndex = 3;
            // 
            // tbLadoB
            // 
            this.tbLadoB.Location = new System.Drawing.Point(191, 73);
            this.tbLadoB.Name = "tbLadoB";
            this.tbLadoB.Size = new System.Drawing.Size(100, 20);
            this.tbLadoB.TabIndex = 4;
            // 
            // tbLadoC
            // 
            this.tbLadoC.Location = new System.Drawing.Point(352, 73);
            this.tbLadoC.Name = "tbLadoC";
            this.tbLadoC.Size = new System.Drawing.Size(100, 20);
            this.tbLadoC.TabIndex = 5;
            // 
            // btCalcular
            // 
            this.btCalcular.Location = new System.Drawing.Point(162, 115);
            this.btCalcular.Name = "btCalcular";
            this.btCalcular.Size = new System.Drawing.Size(163, 23);
            this.btCalcular.TabIndex = 6;
            this.btCalcular.Text = "Verificar Triangulo";
            this.btCalcular.UseVisualStyleBackColor = true;
            this.btCalcular.Click += new System.EventHandler(this.btCalcular_Click);
            // 
            // lbResultado
            // 
            this.lbResultado.AutoSize = true;
            this.lbResultado.Location = new System.Drawing.Point(12, 159);
            this.lbResultado.Name = "lbResultado";
            this.lbResultado.Size = new System.Drawing.Size(121, 13);
            this.lbResultado.TabIndex = 7;
            this.lbResultado.Text = "Aguardando Verificação";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 261);
            this.Controls.Add(this.lbResultado);
            this.Controls.Add(this.btCalcular);
            this.Controls.Add(this.tbLadoC);
            this.Controls.Add(this.tbLadoB);
            this.Controls.Add(this.tbLadoA);
            this.Controls.Add(this.lbLadoC);
            this.Controls.Add(this.lbLadoB);
            this.Controls.Add(this.lbLadoA);
            this.Name = "Form1";
            this.Text = "Triangulos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbLadoA;
        private System.Windows.Forms.Label lbLadoB;
        private System.Windows.Forms.Label lbLadoC;
        private System.Windows.Forms.TextBox tbLadoA;
        private System.Windows.Forms.TextBox tbLadoB;
        private System.Windows.Forms.TextBox tbLadoC;
        private System.Windows.Forms.Button btCalcular;
        private System.Windows.Forms.Label lbResultado;
    }
}

