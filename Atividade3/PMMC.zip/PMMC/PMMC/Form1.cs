﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void lbMensagem_Click(object sender, EventArgs e)
        {

        }

        private void btCalcular_Click(object sender, EventArgs e)
        {
            Double peso, altura, pesoIdeal;

            String mensagem;

            if (Double.TryParse(tbPeso.Text, out peso) && Double.TryParse(tbAltura.Text, out altura))
            {
                if (rbMasculino.Checked)
                    pesoIdeal = (72.7 * altura) - 58;
                else
                    pesoIdeal = (62.1 * altura) - 44.7;

                if (peso > pesoIdeal)
                    mensagem = "Regime Obrigatório Já";
                else if (peso == pesoIdeal)
                    mensagem = "Você está com o peso ideal";
                else
                    mensagem = "Coma bastante massas\ne doces";


                lbMensagem.Text = $"Seu Peso ideal:\n{pesoIdeal}\n{mensagem}"
;            }
            else
                MessageBox.Show("Digite Valores Válidos");
        }
    }
}
