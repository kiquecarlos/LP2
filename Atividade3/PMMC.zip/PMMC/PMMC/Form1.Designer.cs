﻿namespace PMMC
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbSexo = new System.Windows.Forms.GroupBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.rbMasculino = new System.Windows.Forms.RadioButton();
            this.rbFeminino = new System.Windows.Forms.RadioButton();
            this.lbAltura = new System.Windows.Forms.Label();
            this.lbPeso = new System.Windows.Forms.Label();
            this.tbAltura = new System.Windows.Forms.MaskedTextBox();
            this.tbPeso = new System.Windows.Forms.MaskedTextBox();
            this.btCalcular = new System.Windows.Forms.Button();
            this.lbMensagem = new System.Windows.Forms.Label();
            this.gbSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbSexo
            // 
            this.gbSexo.Controls.Add(this.rbFeminino);
            this.gbSexo.Controls.Add(this.rbMasculino);
            this.gbSexo.Location = new System.Drawing.Point(12, 73);
            this.gbSexo.Name = "gbSexo";
            this.gbSexo.Size = new System.Drawing.Size(90, 72);
            this.gbSexo.TabIndex = 0;
            this.gbSexo.TabStop = false;
            this.gbSexo.Text = "Sexo";
            this.gbSexo.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // rbMasculino
            // 
            this.rbMasculino.AutoSize = true;
            this.rbMasculino.Location = new System.Drawing.Point(6, 32);
            this.rbMasculino.Name = "rbMasculino";
            this.rbMasculino.Size = new System.Drawing.Size(34, 17);
            this.rbMasculino.TabIndex = 0;
            this.rbMasculino.TabStop = true;
            this.rbMasculino.Text = "M";
            this.rbMasculino.UseVisualStyleBackColor = true;
            // 
            // rbFeminino
            // 
            this.rbFeminino.AutoSize = true;
            this.rbFeminino.Location = new System.Drawing.Point(46, 32);
            this.rbFeminino.Name = "rbFeminino";
            this.rbFeminino.Size = new System.Drawing.Size(31, 17);
            this.rbFeminino.TabIndex = 1;
            this.rbFeminino.TabStop = true;
            this.rbFeminino.Text = "F";
            this.rbFeminino.UseVisualStyleBackColor = true;
            // 
            // lbAltura
            // 
            this.lbAltura.AutoSize = true;
            this.lbAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAltura.Location = new System.Drawing.Point(8, 9);
            this.lbAltura.Name = "lbAltura";
            this.lbAltura.Size = new System.Drawing.Size(68, 24);
            this.lbAltura.TabIndex = 1;
            this.lbAltura.Text = "Altura :";
            // 
            // lbPeso
            // 
            this.lbPeso.AutoSize = true;
            this.lbPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPeso.Location = new System.Drawing.Point(8, 157);
            this.lbPeso.Name = "lbPeso";
            this.lbPeso.Size = new System.Drawing.Size(105, 24);
            this.lbPeso.TabIndex = 2;
            this.lbPeso.Text = "Peso Atual:";
            // 
            // tbAltura
            // 
            this.tbAltura.Location = new System.Drawing.Point(18, 36);
            this.tbAltura.Mask = "0.00";
            this.tbAltura.Name = "tbAltura";
            this.tbAltura.Size = new System.Drawing.Size(61, 20);
            this.tbAltura.TabIndex = 3;
            // 
            // tbPeso
            // 
            this.tbPeso.Location = new System.Drawing.Point(13, 184);
            this.tbPeso.Mask = "000.00";
            this.tbPeso.Name = "tbPeso";
            this.tbPeso.Size = new System.Drawing.Size(66, 20);
            this.tbPeso.TabIndex = 4;
            // 
            // btCalcular
            // 
            this.btCalcular.Location = new System.Drawing.Point(4, 220);
            this.btCalcular.Name = "btCalcular";
            this.btCalcular.Size = new System.Drawing.Size(75, 44);
            this.btCalcular.TabIndex = 5;
            this.btCalcular.Text = "Calcular MMC";
            this.btCalcular.UseVisualStyleBackColor = true;
            this.btCalcular.Click += new System.EventHandler(this.btCalcular_Click);
            // 
            // lbMensagem
            // 
            this.lbMensagem.AutoSize = true;
            this.lbMensagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMensagem.Location = new System.Drawing.Point(114, 36);
            this.lbMensagem.Name = "lbMensagem";
            this.lbMensagem.Size = new System.Drawing.Size(127, 16);
            this.lbMensagem.TabIndex = 6;
            this.lbMensagem.Text = "Aguardando Dados";
            this.lbMensagem.Click += new System.EventHandler(this.lbMensagem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(291, 269);
            this.Controls.Add(this.lbMensagem);
            this.Controls.Add(this.btCalcular);
            this.Controls.Add(this.tbPeso);
            this.Controls.Add(this.tbAltura);
            this.Controls.Add(this.lbPeso);
            this.Controls.Add(this.lbAltura);
            this.Controls.Add(this.gbSexo);
            this.Name = "Form1";
            this.Text = "PMMC";
            this.gbSexo.ResumeLayout(false);
            this.gbSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbSexo;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.RadioButton rbFeminino;
        private System.Windows.Forms.RadioButton rbMasculino;
        private System.Windows.Forms.Label lbAltura;
        private System.Windows.Forms.Label lbPeso;
        private System.Windows.Forms.MaskedTextBox tbAltura;
        private System.Windows.Forms.MaskedTextBox tbPeso;
        private System.Windows.Forms.Button btCalcular;
        private System.Windows.Forms.Label lbMensagem;
    }
}

