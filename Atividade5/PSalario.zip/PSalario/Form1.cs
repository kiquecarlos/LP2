﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Nome deve ser Preenchido!");
                return;
            }

            double salBruto;
            int filhos;
            if (!double.TryParse(mskSalBruto.Text, out salBruto))
            {
                MessageBox.Show("Valor de Salário Bruto inválido!");
                return;
            }

            if (!int.TryParse(msktxtFilhos.Text, out filhos))
            {
                MessageBox.Show("Quantidade de filhos inválida!");
                return;
            }

            double descINSS;
            double descIRRF;
            double salFamilia;

            descINSS = CalcularINSS(salBruto);
            descIRRF = CalcularIRRF(salBruto);
            salFamilia = CalcularSalFamilia(salBruto, filhos);

            double salLiquido = salBruto + salFamilia - descINSS - descIRRF;

            txtSalLiquido.Text = salLiquido.ToString("N2");

            FormatarMensagem(filhos);
        }

        private double CalcularINSS(double salBruto)
        {
            double aliquota = 0;

            if (salBruto <= 800.47)
            {
                aliquota = 0.075;
            }
            else if (salBruto <= 1050)
            {
                aliquota = 0.0865;
            }
            else if (salBruto <= 1400.77)
            {
                aliquota = 0.09;
            }
            else if (salBruto <= 2901.56)
            {
                aliquota = 0.11;
            }
            else
            {
                aliquota = 0;
            }

            txtAliINSS.Text = aliquota.ToString("P");

            //DESCONTO
            double desconto;
            if (aliquota == 0)
            {
                desconto = 308.17;
            }
            else
            {
                desconto = salBruto * aliquota;
            }

            txtDescINSS.Text = desconto.ToString("N2");

            return desconto;
        }

        private double CalcularIRRF(double salBruto)
        {
            double aliquota;

            if (salBruto <= 1257.12)
            {
                aliquota = 0;
            }
            else if (salBruto <= 2512.08)
            {
                aliquota = 0.15;
            }
            else
            {
                aliquota = 0.275;
            }

            txtAliIRRF.Text = aliquota.ToString("P");

            //DESCONTO

            double desconto;
            if (aliquota == 0)
            {
                desconto = 0;
            }
            else
            {
                desconto = salBruto * aliquota;
            }

            txtDescIRRF.Text = desconto.ToString("N2");

            return desconto;
        }

        private double CalcularSalFamilia(double salBruto, int filhos)
        {
            double salFamilia;

            if (salBruto <= 453.52)
            {
                salFamilia = 22.33;
            }
            else if (salBruto <= 654.61)
            {
                salFamilia = 15.74;
            }
            else
            {
                salFamilia = 0;
            }

            salFamilia = salFamilia * filhos;

            txtSalFamilia.Text = salFamilia.ToString("N2");

            return salFamilia;
        }

        private void FormatarMensagem(int filhos)
        {
            string msg = "Os descontos do salário $tratamento\n que é $estadocivil\n e que $filhos são:";

            //FEMININO OU MASCULINO
            if (rdbtnFem.Checked)
            {
                msg = msg.Replace("$tratamento", "da " + txtNome.Text);
            }
            else
            {
                msg = msg.Replace("$tratamento", "do " + txtNome.Text);
            }

            //ESTADO CIVIL
            if (ckboxCasado.Checked && rdbtnFem.Checked)
            {
                msg = msg.Replace("$estadocivil", "casada");
            }
            else if (ckboxCasado.Checked && rdbtnMasc.Checked)
            {
                msg = msg.Replace("$estadocivil", "casado");
            }
            else if (!ckboxCasado.Checked && rdbtnFem.Checked)
            {
                msg = msg.Replace("$estadocivil", "solteira");
            }
            else
            {
                msg = msg.Replace("$estadocivil", "solteiro");
            }

            //QTD FILHOS
            if (filhos == 0)
            {
                msg = msg.Replace("$filhos", "não tem filhos");
            }
            else if (filhos == 1)
            {
                msg = msg.Replace("$filhos", "tem 1 filho");
            }
            else
            {
                msg = msg.Replace("$filhos", "tem " + filhos + " filhos");
            }

            lbldados.Text = msg;
        }

        private void txtNome_Leave(object sender, EventArgs e)
        {
            //Primeira letra maiuscula do nome

            CultureInfo culture_info = Thread.CurrentThread.CurrentCulture;
            TextInfo text_info = culture_info.TextInfo;
            txtNome.Text = text_info.ToTitleCase(txtNome.Text);
        }
    }
}