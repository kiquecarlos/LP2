﻿namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtAliINSS = new System.Windows.Forms.TextBox();
            this.txtAliIRRF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.txtDescIRRF = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbtnMasc = new System.Windows.Forms.RadioButton();
            this.rdbtnFem = new System.Windows.Forms.RadioButton();
            this.ckboxCasado = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbldados = new System.Windows.Forms.Label();
            this.mskSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.msktxtFilhos = new System.Windows.Forms.MaskedTextBox();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(-3, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Salário Bruto";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Filhos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 197);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Aliquota INSS";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 235);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Aliquota IRRF";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 267);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Salário Família";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 300);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Salário Líquido";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(193, 201);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Desconto INSS";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(193, 239);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Desconto IRPF";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(70, 25);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 0;
            this.txtNome.Leave += new System.EventHandler(this.txtNome_Leave);
            // 
            // txtAliINSS
            // 
            this.txtAliINSS.Enabled = false;
            this.txtAliINSS.Location = new System.Drawing.Point(84, 194);
            this.txtAliINSS.Name = "txtAliINSS";
            this.txtAliINSS.Size = new System.Drawing.Size(100, 20);
            this.txtAliINSS.TabIndex = 12;
            // 
            // txtAliIRRF
            // 
            this.txtAliIRRF.Enabled = false;
            this.txtAliIRRF.Location = new System.Drawing.Point(84, 232);
            this.txtAliIRRF.Name = "txtAliIRRF";
            this.txtAliIRRF.Size = new System.Drawing.Size(100, 20);
            this.txtAliIRRF.TabIndex = 13;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Location = new System.Drawing.Point(84, 264);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(100, 20);
            this.txtSalFamilia.TabIndex = 14;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Enabled = false;
            this.txtSalLiquido.Location = new System.Drawing.Point(84, 298);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.Size = new System.Drawing.Size(100, 20);
            this.txtSalLiquido.TabIndex = 15;
            // 
            // txtDescIRRF
            // 
            this.txtDescIRRF.Enabled = false;
            this.txtDescIRRF.Location = new System.Drawing.Point(273, 236);
            this.txtDescIRRF.Name = "txtDescIRRF";
            this.txtDescIRRF.Size = new System.Drawing.Size(100, 20);
            this.txtDescIRRF.TabIndex = 17;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(274, 194);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(100, 20);
            this.txtDescINSS.TabIndex = 16;
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(196, 102);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(113, 23);
            this.btnVerificar.TabIndex = 6;
            this.btnVerificar.Text = "Verificar Desconto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbtnMasc);
            this.groupBox1.Controls.Add(this.rdbtnFem);
            this.groupBox1.Location = new System.Drawing.Point(196, 17);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(106, 79);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sexo";
            // 
            // rdbtnMasc
            // 
            this.rdbtnMasc.AutoSize = true;
            this.rdbtnMasc.Location = new System.Drawing.Point(7, 49);
            this.rdbtnMasc.Name = "rdbtnMasc";
            this.rdbtnMasc.Size = new System.Drawing.Size(73, 17);
            this.rdbtnMasc.TabIndex = 4;
            this.rdbtnMasc.Text = "Masculino";
            this.rdbtnMasc.UseVisualStyleBackColor = true;
            // 
            // rdbtnFem
            // 
            this.rdbtnFem.AutoSize = true;
            this.rdbtnFem.Checked = true;
            this.rdbtnFem.Location = new System.Drawing.Point(7, 20);
            this.rdbtnFem.Name = "rdbtnFem";
            this.rdbtnFem.Size = new System.Drawing.Size(67, 17);
            this.rdbtnFem.TabIndex = 3;
            this.rdbtnFem.TabStop = true;
            this.rdbtnFem.Text = "Feminino";
            this.rdbtnFem.UseVisualStyleBackColor = true;
            // 
            // ckboxCasado
            // 
            this.ckboxCasado.AutoSize = true;
            this.ckboxCasado.Location = new System.Drawing.Point(17, 40);
            this.ckboxCasado.Name = "ckboxCasado";
            this.ckboxCasado.Size = new System.Drawing.Size(62, 17);
            this.ckboxCasado.TabIndex = 5;
            this.ckboxCasado.Text = "Casado";
            this.ckboxCasado.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.ckboxCasado);
            this.panel1.Location = new System.Drawing.Point(333, 17);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(116, 79);
            this.panel1.TabIndex = 20;
            // 
            // lbldados
            // 
            this.lbldados.AutoSize = true;
            this.lbldados.Location = new System.Drawing.Point(14, 130);
            this.lbldados.Name = "lbldados";
            this.lbldados.Size = new System.Drawing.Size(46, 13);
            this.lbldados.TabIndex = 21;
            this.lbldados.Text = "lbldados";
            // 
            // mskSalBruto
            // 
            this.mskSalBruto.Location = new System.Drawing.Point(70, 58);
            this.mskSalBruto.Mask = "00000.00";
            this.mskSalBruto.Name = "mskSalBruto";
            this.mskSalBruto.Size = new System.Drawing.Size(100, 20);
            this.mskSalBruto.TabIndex = 1;
            // 
            // msktxtFilhos
            // 
            this.msktxtFilhos.Location = new System.Drawing.Point(70, 84);
            this.msktxtFilhos.Mask = "00";
            this.msktxtFilhos.Name = "msktxtFilhos";
            this.msktxtFilhos.Size = new System.Drawing.Size(100, 20);
            this.msktxtFilhos.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(475, 332);
            this.Controls.Add(this.msktxtFilhos);
            this.Controls.Add(this.mskSalBruto);
            this.Controls.Add(this.lbldados);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.txtDescIRRF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliIRRF);
            this.Controls.Add(this.txtAliINSS);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "AA";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtAliINSS;
        private System.Windows.Forms.TextBox txtAliIRRF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.TextBox txtDescIRRF;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbtnMasc;
        private System.Windows.Forms.RadioButton rdbtnFem;
        private System.Windows.Forms.CheckBox ckboxCasado;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbldados;
        private System.Windows.Forms.MaskedTextBox mskSalBruto;
        private System.Windows.Forms.MaskedTextBox msktxtFilhos;
    }
}

